/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex4.c;
import java.util.Scanner;
/**
 *
 * @author pgagl
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        // TODO code application logic here
        
        System.out.println("Digite seu peso(KG): ");
        double p = sc.nextDouble();
        System.out.println("Digite sua altura(M): ");
        double a = sc.nextDouble();
        
        double IMC = p/a;
        
        System.out.println("Seu IMC eh: " + IMC);
    }
    
}

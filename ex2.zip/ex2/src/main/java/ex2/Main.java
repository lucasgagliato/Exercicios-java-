/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex2;
import java.util.Scanner;
/**
 *
 * @author pgagl
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        // TODO code application logic here
   
        
        System.out.println("digite seu nome: ");
        String N = sc.nextLine();
        System.out.println("digite sua nota: ");
        double nota = sc.nextDouble();
        double not2 =  sc.nextDouble();
        double not3 = sc.nextDouble();
        double not4 = sc.nextDouble();
        
        double media =  (nota + not2 + not3 +not4)/4;
        
        System.out.println(media);
        
    }
    
}

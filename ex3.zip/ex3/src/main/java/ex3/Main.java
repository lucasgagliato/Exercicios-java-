/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex3;
import java.util.Scanner;
/**
 *
 * @author pgagl
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        // TODO code application logic here
        System.out.println("Digite um numero para saber sua tabuada: ");
        int tabuada = sc.nextInt();
        int x = 0;
        for(x=1; x<= 10;x++){
            System.out.println(x * tabuada);
        }
    }
    
}
